<?php
/* Copyright (C) 2026 BankAudit module
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    custom/bankaudit/reports.php
 * \ingroup bankaudit
 * \brief   Advanced financial reports on bank flows (Spec 7 / P9).
 */

$res = 0;
if (!$res && file_exists("../../main.inc.php")) {
	$res = include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

dol_include_once('/bankaudit/class/bankaudit.class.php');

$langs->loadLangs(array('banks', 'compta', 'categories', 'bankaudit@bankaudit'));

if (!isModEnabled('bankaudit')) {
	accessforbidden();
}
if (!$user->hasRight('bankaudit', 'read') || !$user->hasRight('banque', 'lire')) {
	accessforbidden();
}

$action = GETPOST('action', 'aZ09');
$reporttype = GETPOST('reporttype', 'aZ09');
if ($reporttype === '') {
	$reporttype = 'cashflow';
}

$date_start = dol_mktime(0, 0, 0, GETPOSTINT('date_startmonth'), GETPOSTINT('date_startday'), GETPOSTINT('date_startyear'));
$date_end = dol_mktime(23, 59, 59, GETPOSTINT('date_endmonth'), GETPOSTINT('date_endday'), GETPOSTINT('date_endyear'));
if (empty($date_start)) {
	$date_start = dol_mktime(0, 0, 0, 1, 1, (int) dol_print_date(dol_now(), '%Y'));
}
if (empty($date_end)) {
	$date_end = dol_now();
}

$mainCurrency = $conf->currency;
$d1 = $db->idate($date_start);
$d2 = $db->idate($date_end);
$entityfilter = getEntity('bank_account');


/**
 * Build the selected report and return its structure.
 *
 * @param DoliDB $db           Database handler
 * @param string $type         Report type
 * @param string $d1           Start date (db format)
 * @param string $d2           End date (db format)
 * @param string $entityfilter Entity SQL fragment
 * @param string $mainCurrency Main currency code
 * @param Translate $langs     Language object
 * @return array               array('head'=>[], 'rows'=>[[]], 'align'=>[])
 */
function bankaudit_build_report($db, $type, $d1, $d2, $entityfilter, $mainCurrency, $langs)
{
	$head = array();
	$rows = array();

	if ($type === 'category') {
		$head = array($langs->trans('Category'), $langs->trans('Currency'), $langs->trans('NbOperations'), $langs->trans('NetBalance'), $langs->trans('AverageAmount'));
		$sql = "SELECT cat.label as categorie, ba.currency_code as cur,";
		$sql .= " COUNT(b.rowid) as nb, SUM(b.amount) as net, AVG(b.amount) as moy";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank as b";
		$sql .= " INNER JOIN ".MAIN_DB_PREFIX."bank_account as ba ON ba.rowid = b.fk_account";
		$sql .= " INNER JOIN ".MAIN_DB_PREFIX."bank_class as bc ON bc.lineid = b.rowid";
		$sql .= " INNER JOIN ".MAIN_DB_PREFIX."categorie as cat ON cat.rowid = bc.fk_categ";
		$sql .= " WHERE ba.entity IN (".$entityfilter.")";
		$sql .= " AND b.dateo BETWEEN '".$d1."' AND '".$d2."'";
		$sql .= " GROUP BY cat.rowid, cat.label, ba.currency_code";
		$sql .= " ORDER BY ABS(SUM(b.amount)) DESC";
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$rows[] = array(
					$obj->categorie,
					$obj->cur,
					(int) $obj->nb,
					price($obj->net, 0, $langs, 1, -1, -1, $obj->cur),
					price(price2num($obj->moy, 'MT'), 0, $langs, 1, -1, -1, $obj->cur),
				);
			}
		}
		return array('head' => $head, 'rows' => $rows);
	}

	if ($type === 'journal') {
		$head = array($langs->trans('Date'), $langs->trans('BankAccount'), $langs->trans('Label'), $langs->trans('Type'), $langs->trans('Amount'));
		$sql = "SELECT b.dateo, b.label, b.amount, b.fk_type, ba.ref, ba.currency_code as cur";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank as b";
		$sql .= " INNER JOIN ".MAIN_DB_PREFIX."bank_account as ba ON ba.rowid = b.fk_account";
		$sql .= " WHERE ba.entity IN (".$entityfilter.")";
		$sql .= " AND b.dateo BETWEEN '".$d1."' AND '".$d2."'";
		$sql .= " ORDER BY b.dateo ASC, b.rowid ASC";
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$rows[] = array(
					dol_print_date($db->jdate($obj->dateo), 'day'),
					$obj->ref,
					$obj->label,
					$obj->fk_type,
					price($obj->amount, 0, $langs, 1, -1, -1, $obj->cur),
				);
			}
		}
		return array('head' => $head, 'rows' => $rows);
	}

	if ($type === 'consolidated') {
		$head = array($langs->trans('BankAccount'), $langs->trans('Currency'), $langs->trans('NetBalance'), $langs->trans('EquivalentMainCurrency', $mainCurrency));
		$sql = "SELECT ba.rowid, ba.ref, ba.label, ba.currency_code as cur, SUM(b.amount) as net";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank_account as ba";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."bank as b ON b.fk_account = ba.rowid AND b.dateo BETWEEN '".$d1."' AND '".$d2."'";
		$sql .= " WHERE ba.entity IN (".$entityfilter.")";
		$sql .= " GROUP BY ba.rowid, ba.ref, ba.label, ba.currency_code";
		$sql .= " ORDER BY ba.ref";
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$net = (float) $obj->net;
				$rate = BankAudit::getConversionRate($db, $obj->cur, $mainCurrency);
				$equiv = ($rate === null) ? null : ($net * $rate);
				$rows[] = array(
					$obj->ref.' - '.$obj->label,
					$obj->cur,
					price($net, 0, $langs, 1, -1, -1, $obj->cur),
					($equiv === null ? '-' : price($equiv, 0, $langs, 1, -1, -1, $mainCurrency)),
				);
			}
		}
		return array('head' => $head, 'rows' => $rows);
	}

	if ($type === 'exchange') {
		// Simplified revaluation: native balance vs current equivalent in main currency
		$head = array($langs->trans('BankAccount'), $langs->trans('Currency'), $langs->trans('NativeBalance'), $langs->trans('EquivalentMainCurrency', $mainCurrency));
		$sql = "SELECT ba.rowid, ba.ref, ba.label, ba.currency_code as cur, SUM(b.amount) as net";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank_account as ba";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."bank as b ON b.fk_account = ba.rowid AND b.dateo BETWEEN '".$d1."' AND '".$d2."'";
		$sql .= " WHERE ba.entity IN (".$entityfilter.") AND ba.currency_code <> '".$db->escape($mainCurrency)."'";
		$sql .= " GROUP BY ba.rowid, ba.ref, ba.label, ba.currency_code";
		$sql .= " ORDER BY ba.ref";
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$net = (float) $obj->net;
				$rate = BankAudit::getConversionRate($db, $obj->cur, $mainCurrency);
				$equiv = ($rate === null) ? null : ($net * $rate);
				$rows[] = array(
					$obj->ref.' - '.$obj->label,
					$obj->cur,
					price($net, 0, $langs, 1, -1, -1, $obj->cur),
					($equiv === null ? '-' : price($equiv, 0, $langs, 1, -1, -1, $mainCurrency)),
				);
			}
		}
		return array('head' => $head, 'rows' => $rows);
	}

	// Default: cash flow by account and month
	$head = array($langs->trans('BankAccount'), $langs->trans('Currency'), $langs->trans('ReportPeriod'), $langs->trans('TotalIn'), $langs->trans('TotalOut'), $langs->trans('NetBalance'));
	$sql = "SELECT ba.ref, ba.label, ba.currency_code as cur,";
	$sql .= " DATE_FORMAT(b.dateo, '%Y-%m') as periode,";
	$sql .= " SUM(CASE WHEN b.amount > 0 THEN b.amount ELSE 0 END) as total_in,";
	$sql .= " SUM(CASE WHEN b.amount < 0 THEN -b.amount ELSE 0 END) as total_out,";
	$sql .= " SUM(b.amount) as net";
	$sql .= " FROM ".MAIN_DB_PREFIX."bank as b";
	$sql .= " INNER JOIN ".MAIN_DB_PREFIX."bank_account as ba ON ba.rowid = b.fk_account";
	$sql .= " WHERE ba.entity IN (".$entityfilter.")";
	$sql .= " AND b.dateo BETWEEN '".$d1."' AND '".$d2."'";
	$sql .= " GROUP BY ba.rowid, ba.ref, ba.label, ba.currency_code, DATE_FORMAT(b.dateo, '%Y-%m')";
	$sql .= " ORDER BY ba.ref, periode";
	$resql = $db->query($sql);
	if ($resql) {
		while ($obj = $db->fetch_object($resql)) {
			$rows[] = array(
				$obj->ref.' - '.$obj->label,
				$obj->cur,
				$obj->periode,
				price($obj->total_in, 0, $langs, 1, -1, -1, $obj->cur),
				price($obj->total_out, 0, $langs, 1, -1, -1, $obj->cur),
				price($obj->net, 0, $langs, 1, -1, -1, $obj->cur),
			);
		}
	}
	return array('head' => $head, 'rows' => $rows);
}


// CSV export
if ($action == 'export') {
	$report = bankaudit_build_report($db, $reporttype, $d1, $d2, $entityfilter, $mainCurrency, $langs);
	$filename = 'report_'.$reporttype.'_'.dol_print_date(dol_now(), '%Y%m%d%H%M').'.csv';
	header('Content-Type: text/csv; charset=UTF-8');
	header('Content-Disposition: attachment; filename="'.$filename.'"');

	$out = implode(';', $report['head'])."\n";
	foreach ($report['rows'] as $row) {
		$clean = array();
		foreach ($row as $cell) {
			$clean[] = '"'.str_replace('"', '""', strip_tags((string) $cell)).'"';
		}
		$out .= implode(';', $clean)."\n";
	}
	print $out;
	$db->close();
	exit;
}


/*
 * View
 */

$form = new Form($db);

llxHeader('', $langs->trans('BankReportsTitle'), '', '', 0, 0, '', '', '', 'mod-bankaudit page-reports');

print load_fiche_titre($langs->trans('BankReportsTitle'), '', 'bank_account');

$reporttypes = array(
	'cashflow' => $langs->trans('ReportCashFlow'),
	'category' => $langs->trans('ReportByCategory'),
	'exchange' => $langs->trans('ReportExchangeGainLoss'),
	'journal' => $langs->trans('ReportBankJournal'),
	'consolidated' => $langs->trans('ReportConsolidated'),
);

// Parameters form
print '<form method="POST" action="'.$_SERVER['PHP_SELF'].'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="generate">';

print '<div class="div-table-responsive-no-min"><table class="noborder centpercent"><tr class="oddeven">';
print '<td>'.$langs->trans('ReportType').'</td>';
print '<td>';
print '<select name="reporttype" class="flat">';
foreach ($reporttypes as $key => $lab) {
	print '<option value="'.$key.'"'.($key === $reporttype ? ' selected' : '').'>'.$lab.'</option>';
}
print '</select>';
print '</td>';
print '<td>'.$langs->trans('ReportDateStart').'</td>';
print '<td>'.$form->selectDate($date_start, 'date_start', 0, 0, 0, '', 1, 0).'</td>';
print '<td>'.$langs->trans('ReportDateEnd').'</td>';
print '<td>'.$form->selectDate($date_end, 'date_end', 0, 0, 0, '', 1, 0).'</td>';
print '<td><input type="submit" class="button" value="'.$langs->trans('GenerateReport').'"></td>';
print '</tr></table></div>';
print '</form>';

print '<br>';

// Build and render the report
$report = bankaudit_build_report($db, $reporttype, $d1, $d2, $entityfilter, $mainCurrency, $langs);

$exporturl = $_SERVER['PHP_SELF'].'?action=export&reporttype='.urlencode($reporttype);
$exporturl .= '&date_startmonth='.dol_print_date($date_start, '%m').'&date_startday='.dol_print_date($date_start, '%d').'&date_startyear='.dol_print_date($date_start, '%Y');
$exporturl .= '&date_endmonth='.dol_print_date($date_end, '%m').'&date_endday='.dol_print_date($date_end, '%d').'&date_endyear='.dol_print_date($date_end, '%Y');

print '<div class="tabsAction">';
print '<a class="butAction" href="'.$exporturl.'">'.$langs->trans('ExportToExcel').'</a>';
print '<a class="butAction" href="javascript:window.print();">'.$langs->trans('ExportToPdf').'</a>';
print '</div>';

print '<div class="div-table-responsive">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre">';
$nbcols = count($report['head']);
foreach ($report['head'] as $i => $col) {
	$cls = ($i >= 2 && $reporttype !== 'journal') ? ' class="right"' : '';
	if ($reporttype === 'journal' && $i == 4) {
		$cls = ' class="right"';
	}
	print '<th'.$cls.'>'.dol_escape_htmltag($col).'</th>';
}
print '</tr>';

if (empty($report['rows'])) {
	print '<tr class="oddeven"><td colspan="'.$nbcols.'" class="opacitymedium center">'.$langs->trans('NoDataForPeriod').'</td></tr>';
} else {
	foreach ($report['rows'] as $row) {
		print '<tr class="oddeven">';
		foreach ($row as $i => $cell) {
			$cls = '';
			if ($reporttype === 'journal') {
				$cls = ($i == 4) ? ' class="right nowraponall"' : '';
			} else {
				$cls = ($i >= 2 && !($reporttype === 'cashflow' && $i == 2)) ? ' class="right nowraponall"' : '';
			}
			print '<td'.$cls.'>'.dol_escape_htmltag((string) $cell).'</td>';
		}
		print '</tr>';
	}
}
print '</table>';
print '</div>';

// End of page
llxFooter();
$db->close();

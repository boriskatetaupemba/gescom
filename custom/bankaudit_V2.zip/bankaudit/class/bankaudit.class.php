<?php
/* Copyright (C) 2026 BankAudit module
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    custom/bankaudit/class/bankaudit.class.php
 * \ingroup bankaudit
 * \brief   Shared helpers for the BankAudit module (logging, transfer sync, currency conversion).
 */


/**
 * Utility class gathering shared helpers used by triggers, hooks and pages.
 */
class BankAudit
{
	/**
	 * Anti-recursion guard. Set to true while a synchronization is being propagated
	 * to a linked transfer line, so nested triggers/hooks do not loop.
	 *
	 * @var bool
	 */
	public static $syncInProgress = false;

	/**
	 * Insert a row into the audit log table.
	 *
	 * @param DoliDB      $db          Database handler
	 * @param User        $user        Acting user
	 * @param string      $object_type 'bank_account' | 'bank_line'
	 * @param int         $object_id   Rowid of the concerned object
	 * @param string      $action      'CREATE' | 'UPDATE' | 'DELETE'
	 * @param string|null $field_name  Modified field (NULL for CREATE/DELETE)
	 * @param string|null $old_value   Old value
	 * @param string|null $new_value   New value
	 * @param string|null $context     JSON context (optional)
	 * @return int                     1 if OK, -1 if KO
	 */
	public static function logChange($db, $user, $object_type, $object_id, $action, $field_name = null, $old_value = null, $new_value = null, $context = null)
	{
		global $conf;

		$now = dol_now();
		$ip = function_exists('getUserRemoteIP') ? getUserRemoteIP() : (empty($_SERVER['REMOTE_ADDR']) ? '' : $_SERVER['REMOTE_ADDR']);
		$userid = is_object($user) && !empty($user->id) ? (int) $user->id : 0;

		$sql = "INSERT INTO ".MAIN_DB_PREFIX."bank_audit_log";
		$sql .= " (tms, entity, fk_user, object_type, object_id, action, field_name, old_value, new_value, ip, context)";
		$sql .= " VALUES (";
		$sql .= "'".$db->idate($now)."',";
		$sql .= " ".((int) $conf->entity).",";
		$sql .= " ".$userid.",";
		$sql .= " '".$db->escape($object_type)."',";
		$sql .= " ".((int) $object_id).",";
		$sql .= " '".$db->escape($action)."',";
		$sql .= " ".($field_name === null ? "NULL" : "'".$db->escape($field_name)."'").",";
		$sql .= " ".($old_value === null ? "NULL" : "'".$db->escape((string) $old_value)."'").",";
		$sql .= " ".($new_value === null ? "NULL" : "'".$db->escape((string) $new_value)."'").",";
		$sql .= " ".($ip === '' ? "NULL" : "'".$db->escape($ip)."'").",";
		$sql .= " ".($context === null ? "NULL" : "'".$db->escape($context)."'");
		$sql .= ")";

		return $db->query($sql) ? 1 : -1;
	}

	/**
	 * Return the rowid of the bank line linked to the given one through an internal transfer.
	 *
	 * @param DoliDB $db     Database handler
	 * @param int    $lineid Bank line rowid
	 * @return int           Linked bank line rowid, or 0 if none
	 */
	public static function getLinkedTransferLine($db, $lineid)
	{
		$sql = "SELECT url_id FROM ".MAIN_DB_PREFIX."bank_url";
		$sql .= " WHERE fk_bank = ".((int) $lineid)." AND type = 'banktransfert'";
		$sql .= " LIMIT 1";

		$resql = $db->query($sql);
		if ($resql && ($obj = $db->fetch_object($resql))) {
			return (int) $obj->url_id;
		}
		return 0;
	}

	/**
	 * Return the ISO currency code of a bank account.
	 *
	 * @param DoliDB $db        Database handler
	 * @param int    $accountid Bank account rowid
	 * @return string           Currency code (ex: 'USD') or '' if not found
	 */
	public static function getAccountCurrency($db, $accountid)
	{
		$sql = "SELECT currency_code FROM ".MAIN_DB_PREFIX."bank_account WHERE rowid = ".((int) $accountid);
		$resql = $db->query($sql);
		if ($resql && ($obj = $db->fetch_object($resql))) {
			return $obj->currency_code;
		}
		return '';
	}

	/**
	 * Return a human readable name (label, or ref) of a bank account.
	 *
	 * @param DoliDB $db        Database handler
	 * @param int    $accountid Bank account rowid
	 * @return string           Account name or '' if not found
	 */
	public static function getAccountLabel($db, $accountid)
	{
		$sql = "SELECT ref, label FROM ".MAIN_DB_PREFIX."bank_account WHERE rowid = ".((int) $accountid);
		$resql = $db->query($sql);
		if ($resql && ($obj = $db->fetch_object($resql))) {
			$name = trim((string) $obj->label);
			if ($name === '') {
				$name = trim((string) $obj->ref);
			}
			return $name;
		}
		return '';
	}

	/**
	 * Return whether the balance guard before transfer is globally enabled.
	 *
	 * @return bool   True when enabled (default), false when disabled in setup
	 */
	public static function isBalanceGuardEnabled()
	{
		return getDolGlobalString('BANKAUDIT_ENABLE_BALANCE_GUARD', '1') == '1';
	}

	/**
	 * Return the map of bank account rowid => ref for the current entity.
	 * Used to display only the account reference on the transfer form.
	 *
	 * @param DoliDB $db Database handler
	 * @return array     Associative array id => ref
	 */
	public static function getAccountsRefMap($db)
	{
		$map = array();
		$sql = "SELECT rowid, ref, label FROM ".MAIN_DB_PREFIX."bank_account";
		$sql .= " WHERE entity IN (".getEntity('bank_account').")";
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$ref = trim((string) $obj->ref);
				if ($ref === '') {
					$ref = trim((string) $obj->label);
				}
				$map[(int) $obj->rowid] = $ref;
			}
		}
		return $map;
	}

	/**
	 * Return display data for the bank line linked to the given one through an internal transfer.
	 *
	 * @param DoliDB $db     Database handler
	 * @param int    $lineid Source bank line rowid
	 * @return array|null    Display data, or null when there is no linked line
	 */
	public static function getLinkedLineDisplay($db, $lineid)
	{
		$linkedId = self::getLinkedTransferLine($db, $lineid);
		if ($linkedId <= 0 || $linkedId == $lineid) {
			return null;
		}

		$sql = "SELECT b.rowid, b.label, b.amount, b.dateo, b.datev, b.fk_type, b.fk_account,";
		$sql .= " ba.ref as account_ref, ba.label as account_label, ba.currency_code,";
		$sql .= " pt.libelle as type_label";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank as b";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."bank_account as ba ON ba.rowid = b.fk_account";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."c_paiement as pt ON pt.code = b.fk_type AND pt.entity IN (".getEntity('c_paiement').")";
		$sql .= " WHERE b.rowid = ".((int) $linkedId);
		$resql = $db->query($sql);
		if (!$resql || !($obj = $db->fetch_object($resql))) {
			return null;
		}

		$accountName = trim((string) $obj->account_label);
		if ($accountName === '') {
			$accountName = trim((string) $obj->account_ref);
		}

		return array(
			'id' => (int) $obj->rowid,
			'account_id' => (int) $obj->fk_account,
			'account_name' => $accountName,
			'account_ref' => (string) $obj->account_ref,
			'currency_code' => (string) $obj->currency_code,
			'label' => (string) $obj->label,
			'amount' => (float) $obj->amount,
			'dateo' => $db->jdate($obj->dateo),
			'datev' => $db->jdate($obj->datev),
			'type' => trim((string) $obj->type_label) !== '' ? (string) $obj->type_label : (string) $obj->fk_type,
		);
	}

	/**
	 * Return the ISO currency code from a multicurrency rowid.
	 *
	 * @param DoliDB $db Database handler
	 * @param int    $id llx_multicurrency rowid
	 * @return string    Currency code or '' if not found
	 */
	public static function getCurrencyCodeById($db, $id)
	{
		$sql = "SELECT code FROM ".MAIN_DB_PREFIX."multicurrency WHERE rowid = ".((int) $id);
		$resql = $db->query($sql);
		if ($resql && ($obj = $db->fetch_object($resql))) {
			return $obj->code;
		}
		return '';
	}

	/**
	 * Return the conversion factor to apply to convert an amount from one currency to another.
	 * Uses the authoritative Dolibarr multicurrency rates (foreign units per 1 main currency).
	 *
	 * amount_to = amount_from * getConversionRate(from, to)
	 *
	 * @param DoliDB $db   Database handler
	 * @param string $from Source currency code
	 * @param string $to   Target currency code
	 * @return float|null  Conversion factor, or null if a required rate is unknown
	 */
	public static function getConversionRate($db, $from, $to)
	{
		global $conf;

		if ($from === $to) {
			return 1.0;
		}
		if (!isModEnabled('multicurrency')) {
			return null;
		}

		require_once DOL_DOCUMENT_ROOT.'/multicurrency/class/multicurrency.class.php';

		$main = $conf->currency;
		$rateFrom = 1.0;
		$rateTo = 1.0;

		if ($from !== $main) {
			$r = MultiCurrency::getIdAndTxFromCode($db, $from);
			if (empty($r[0])) {
				return null; // unknown rate for source currency
			}
			$rateFrom = (float) $r[1];
		}
		if ($to !== $main) {
			$r = MultiCurrency::getIdAndTxFromCode($db, $to);
			if (empty($r[0])) {
				return null; // unknown rate for target currency
			}
			$rateTo = (float) $r[1];
		}

		if ($rateFrom <= 0 || $rateTo <= 0) {
			return null;
		}

		return $rateTo / $rateFrom;
	}

	/**
	 * Return the current balance of a bank account (sum of all bank lines).
	 *
	 * @param DoliDB $db            Database handler
	 * @param int    $accountid     Bank account rowid
	 * @param bool   $excludeFuture If true, exclude lines with an operation date in the future
	 * @return float                Account balance in the account currency
	 */
	public static function getAccountBalance($db, $accountid, $excludeFuture = false)
	{
		$sql = "SELECT COALESCE(SUM(amount), 0) as solde FROM ".MAIN_DB_PREFIX."bank";
		$sql .= " WHERE fk_account = ".((int) $accountid);
		if ($excludeFuture) {
			$sql .= " AND dateo <= '".$db->idate(dol_now())."'";
		}
		$resql = $db->query($sql);
		if ($resql && ($obj = $db->fetch_object($resql))) {
			return (float) $obj->solde;
		}
		return 0.0;
	}

	/**
	 * Return the balance of a bank account at a given point in time (operations up to $tsmax).
	 *
	 * @param DoliDB $db        Database handler
	 * @param int    $accountid Bank account rowid
	 * @param int    $tsmax     Timestamp (operations with dateo <= this date are summed)
	 * @return float            Account balance in the account currency at that date
	 */
	public static function getBalanceAsOf($db, $accountid, $tsmax)
	{
		$sql = "SELECT COALESCE(SUM(amount), 0) as solde FROM ".MAIN_DB_PREFIX."bank";
		$sql .= " WHERE fk_account = ".((int) $accountid);
		$sql .= " AND dateo <= '".$db->idate($tsmax)."'";
		$resql = $db->query($sql);
		if ($resql && ($obj = $db->fetch_object($resql))) {
			return (float) $obj->solde;
		}
		return 0.0;
	}

	/**
	 * Return the list of category ids attached to a bank line.
	 *
	 * @param DoliDB $db     Database handler
	 * @param int    $lineid Bank line rowid
	 * @return int[]         Array of category ids
	 */
	public static function getLineCategories($db, $lineid)
	{
		$cats = array();
		$sql = "SELECT fk_categ FROM ".MAIN_DB_PREFIX."bank_class WHERE lineid = ".((int) $lineid);
		$resql = $db->query($sql);
		if ($resql) {
			while ($obj = $db->fetch_object($resql)) {
				$cats[] = (int) $obj->fk_categ;
			}
		}
		return $cats;
	}

	/**
	 * Replace the categories of a bank line with the given set.
	 *
	 * @param DoliDB $db           Database handler
	 * @param int    $targetlineid Bank line rowid
	 * @param int[]  $categids      Category ids to set
	 * @return int                 1 if OK
	 */
	public static function syncLineCategories($db, $targetlineid, $categids)
	{
		$db->query("DELETE FROM ".MAIN_DB_PREFIX."bank_class WHERE lineid = ".((int) $targetlineid));
		foreach ($categids as $cid) {
			$cid = (int) $cid;
			if ($cid <= 0) {
				continue;
			}
			$db->query("INSERT INTO ".MAIN_DB_PREFIX."bank_class (lineid, fk_categ) VALUES (".((int) $targetlineid).", ".$cid.")");
		}
		return 1;
	}

	/**
	 * Return the minimum balance threshold configured for an account, expressed in the
	 * account's own currency. Returns null when no threshold is configured (no blocking).
	 *
	 * @param DoliDB $db        Database handler
	 * @param int    $accountid Bank account rowid
	 * @return float|null       Threshold in the account currency, or null
	 */
	public static function getMinBalanceForAccount($db, $accountid)
	{
		global $conf;

		$sql = "SELECT seuil_min, seuil_devise FROM ".MAIN_DB_PREFIX."bank_dashboard_config";
		$sql .= " WHERE fk_account = ".((int) $accountid)." AND entity = ".((int) $conf->entity);
		$resql = $db->query($sql);
		if (!$resql || !($obj = $db->fetch_object($resql))) {
			return null;
		}
		if ($obj->seuil_min === null || $obj->seuil_min === '') {
			return null;
		}

		$threshold = (float) $obj->seuil_min;
		$seuilCurrency = $obj->seuil_devise;
		$accountCurrency = self::getAccountCurrency($db, $accountid);

		if ($seuilCurrency && $accountCurrency && $seuilCurrency !== $accountCurrency) {
			$rate = self::getConversionRate($db, $seuilCurrency, $accountCurrency);
			if ($rate !== null) {
				$threshold = $threshold * $rate;
			}
			// If the rate is unknown we keep the raw threshold value as a safe fallback.
		}

		return $threshold;
	}

	/**
	 * Record an exchange rate change into the rate history table and flag large variations.
	 *
	 * @param DoliDB $db        Database handler
	 * @param User   $user      Acting user
	 * @param string $code_from Source currency (main currency)
	 * @param string $code_to   Target currency
	 * @param float  $rate_new  New rate
	 * @param string $source    'manual' | 'api'
	 * @return array            array('alerte'=>int, 'variation'=>float|null, 'rate_old'=>float|null)
	 */
	public static function logRateChange($db, $user, $code_from, $code_to, $rate_new, $source = 'manual')
	{
		global $conf;

		$sql = "SELECT rate_new FROM ".MAIN_DB_PREFIX."bank_rate_history";
		$sql .= " WHERE code_from = '".$db->escape($code_from)."' AND code_to = '".$db->escape($code_to)."'";
		$sql .= " AND entity = ".((int) $conf->entity);
		$sql .= " ORDER BY tms DESC LIMIT 1";
		$resql = $db->query($sql);
		$rate_old = null;
		if ($resql && ($obj = $db->fetch_object($resql))) {
			$rate_old = (float) $obj->rate_new;
		}

		$variation = null;
		$alerte = 0;
		$threshold = (float) getDolGlobalString('BANKAUDIT_RATE_ALERT_THRESHOLD', '10');
		if ($rate_old !== null && $rate_old > 0) {
			$variation = abs(($rate_new - $rate_old) / $rate_old * 100);
			if ($variation > $threshold) {
				$alerte = 1;
			}
		}

		$now = dol_now();
		$ip = function_exists('getUserRemoteIP') ? getUserRemoteIP() : (empty($_SERVER['REMOTE_ADDR']) ? '' : $_SERVER['REMOTE_ADDR']);
		$userid = is_object($user) && !empty($user->id) ? (int) $user->id : 0;

		$sql = "INSERT INTO ".MAIN_DB_PREFIX."bank_rate_history";
		$sql .= " (tms, entity, fk_user, code_from, code_to, rate_old, rate_new, variation_pct, alerte, ip, source)";
		$sql .= " VALUES (";
		$sql .= "'".$db->idate($now)."',";
		$sql .= " ".((int) $conf->entity).",";
		$sql .= " ".$userid.",";
		$sql .= " '".$db->escape($code_from)."',";
		$sql .= " '".$db->escape($code_to)."',";
		$sql .= " ".($rate_old === null ? "NULL" : (float) $rate_old).",";
		$sql .= " ".((float) $rate_new).",";
		$sql .= " ".($variation === null ? "NULL" : (float) $variation).",";
		$sql .= " ".((int) $alerte).",";
		$sql .= " ".($ip === '' ? "NULL" : "'".$db->escape($ip)."'").",";
		$sql .= " '".$db->escape($source)."'";
		$sql .= ")";
		$db->query($sql);

		return array('alerte' => $alerte, 'variation' => $variation, 'rate_old' => $rate_old);
	}
}

<?php
/* Copyright (C) 2026 BankAudit module
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    custom/bankaudit/class/actions_bankaudit.class.php
 * \ingroup bankaudit
 * \brief   Hook overloads for the BankAudit module.
 *
 * Handles, on the native bank pages:
 *  - bankline  : audit of line modifications, synchronization of the linked transfer line,
 *                anomaly detection, and display of the change history (Suivi).
 *  - banktransfer : server-side balance guard (P2) and client-side conversion / balance
 *                   assistant injected into transfer.php (P3 + P2).
 */

require_once DOL_DOCUMENT_ROOT.'/core/class/commonhookactions.class.php';
dol_include_once('/bankaudit/class/bankaudit.class.php');
dol_include_once('/bankaudit/class/bankauditanomaly.class.php');


/**
 * Class ActionsBankaudit
 */
class ActionsBankaudit extends CommonHookActions
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;

	/**
	 * @var string Error code (or message)
	 */
	public $error = '';

	/**
	 * @var array Errors
	 */
	public $errors = array();

	/**
	 * @var array Hook results.
	 */
	public $results = array();

	/**
	 * @var ?string String displayed by executeHook() immediately after return
	 */
	public $resprints;

	/**
	 * @var int Priority of hook
	 */
	public $priority;

	/**
	 * Snapshots of bank lines captured before a modification, keyed by line id.
	 *
	 * @var array
	 */
	private static $pendingLineUpdate = array();

	/**
	 * Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * doActions hook.
	 *  - bankline    : capture the old line values before the native update.
	 *  - banktransfer: server-side balance guard (blocks the native 'add' when insufficient).
	 *
	 * @param array        $parameters  Hook metadata (currentcontext, ...)
	 * @param CommonObject $object      Current object
	 * @param string       $action      Current action
	 * @param HookManager  $hookmanager Hook manager
	 * @return int                      0 on success
	 */
	public function doActions($parameters, &$object, &$action, $hookmanager)
	{
		global $user, $langs;

		$context = empty($parameters['currentcontext']) ? '' : $parameters['currentcontext'];

		// Capture the line state before the native update of compta/bank/line.php
		if ($context == 'bankline') {
			if ($action == 'update' && $user->hasRight('banque', 'modifier')) {
				$lineid = GETPOSTINT('rowid');
				if ($lineid > 0) {
					$snapshot = $this->fetchBankLineSnapshot($lineid);
					if ($snapshot !== null) {
						self::$pendingLineUpdate[$lineid] = $snapshot;
					}
				}
			}
		}

		// Server-side balance guard on the internal transfer page (P2)
		if ($context == 'banktransfer') {
			if ($action == 'add' && $user->hasRight('banque', 'transfer')) {
				if ($this->checkTransferBalances($langs)) {
					// Prevent the native 'add' processing by neutralizing the action
					$action = '';
				}
			}
		}

		return 0;
	}

	/**
	 * formObjectOptions hook (bankline context): process the pending modification
	 * (logging + synchronization + anomaly detection) and render the change history.
	 *
	 * @param array        $parameters  Hook metadata
	 * @param CommonObject $object      AccountLine being displayed
	 * @param string       $action      Current action
	 * @param HookManager  $hookmanager Hook manager
	 * @return int                      0 on success
	 */
	public function formObjectOptions($parameters, &$object, &$action, $hookmanager)
	{
		global $user, $langs;

		$context = empty($parameters['currentcontext']) ? '' : $parameters['currentcontext'];
		if ($context != 'bankline') {
			return 0;
		}
		if (!is_object($object) || empty($object->id) || (isset($object->element) && $object->element != 'bank')) {
			return 0;
		}

		$lineid = (int) $object->id;

		// Process the modification that has just been persisted by the native code
		if (isset(self::$pendingLineUpdate[$lineid])) {
			$old = self::$pendingLineUpdate[$lineid];
			unset(self::$pendingLineUpdate[$lineid]);
			$this->processLineModification($user, $lineid, $old);
		}

		// Always render the audit / tracking history for this line
		$this->resprints = $this->renderLineHistory($langs, $lineid);

		return 0;
	}

	/**
	 * printCommonFooter hook: inject the conversion / balance assistant into transfer.php.
	 *
	 * @param array        $parameters  Hook metadata
	 * @param CommonObject $object      Current object
	 * @param string       $action      Current action
	 * @param HookManager  $hookmanager Hook manager
	 * @return int                      0 on success
	 */
	public function printCommonFooter($parameters, &$object, &$action, $hookmanager)
	{
		global $langs;

		$context = empty($parameters['currentcontext']) ? '' : $parameters['currentcontext'];
		if ($context == 'banktransfer') {
			print $this->getTransferAssistantJs($langs);
		}

		return 0;
	}

	/**
	 * Read the tracked fields of a bank line from the database.
	 *
	 * @param int $lineid Bank line rowid
	 * @return array|null  Snapshot array, or null if the line does not exist
	 */
	private function fetchBankLineSnapshot($lineid)
	{
		$sql = "SELECT rowid, fk_account, fk_type, amount, label, dateo, datev, num_chq, banque, emetteur, rappro";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank WHERE rowid = ".((int) $lineid);
		$resql = $this->db->query($sql);
		if (!$resql || !($obj = $this->db->fetch_object($resql))) {
			return null;
		}

		return array(
			'fk_account' => (int) $obj->fk_account,
			'fk_type' => (string) $obj->fk_type,
			'amount' => (float) $obj->amount,
			'label' => (string) $obj->label,
			'dateo' => (string) $obj->dateo,
			'datev' => (string) $obj->datev,
			'num_chq' => (string) $obj->num_chq,
			'banque' => (string) $obj->banque,
			'emetteur' => (string) $obj->emetteur,
			'rappro' => (int) $obj->rappro,
			'categs' => BankAudit::getLineCategories($this->db, $lineid),
		);
	}

	/**
	 * Compute the differences between the old and the new state of a bank line,
	 * log them, propagate the change to the linked transfer line and run anomaly checks.
	 *
	 * @param User $user   Acting user
	 * @param int  $lineid Bank line rowid
	 * @param array $old   Old snapshot
	 * @return void
	 */
	private function processLineModification($user, $lineid, $old)
	{
		$new = $this->fetchBankLineSnapshot($lineid);
		if ($new === null) {
			return;
		}

		// Scalar fields tracked for both logging and propagation
		$fields = array('fk_account', 'fk_type', 'amount', 'label', 'dateo', 'datev', 'num_chq', 'banque', 'emetteur');

		$changed = array();
		foreach ($fields as $field) {
			if ((string) $old[$field] !== (string) $new[$field]) {
				$changed[$field] = array($old[$field], $new[$field]);
				BankAudit::logChange($this->db, $user, 'bank_line', $lineid, 'UPDATE', $field, (string) $old[$field], (string) $new[$field]);
			}
		}

		// Categories
		$oldc = $old['categs'];
		$newc = $new['categs'];
		sort($oldc);
		sort($newc);
		$catsChanged = ($oldc != $newc);
		if ($catsChanged) {
			BankAudit::logChange($this->db, $user, 'bank_line', $lineid, 'UPDATE', 'categories', implode(',', $oldc), implode(',', $newc));
		}

		// Propagate to the linked transfer line
		if (!empty($changed) || $catsChanged) {
			$this->syncLinkedLine($user, $lineid, $new, $changed, $catsChanged);
		}

		// Anomaly detection on the modified line
		BankAuditAnomaly::checkLine($this->db, $user, $lineid);
	}

	/**
	 * Propagate the modified fields of a transfer line to the line it is linked to,
	 * applying the currency rule on the amount and avoiding infinite recursion.
	 *
	 * @param User  $user        Acting user
	 * @param int   $lineid      Source line rowid
	 * @param array $new         New snapshot of the source line
	 * @param array $changed     Map of changed scalar fields
	 * @param bool  $catsChanged Whether categories changed
	 * @return void
	 */
	private function syncLinkedLine($user, $lineid, $new, $changed, $catsChanged)
	{
		if (BankAudit::$syncInProgress) {
			return;
		}

		$linkedId = BankAudit::getLinkedTransferLine($this->db, $lineid);
		if ($linkedId <= 0 || $linkedId == $lineid) {
			return;
		}

		$linked = $this->fetchBankLineSnapshot($linkedId);
		if ($linked === null) {
			return;
		}

		BankAudit::$syncInProgress = true;

		$setparts = array();

		// Fields propagated identically
		foreach (array('fk_type', 'emetteur', 'banque', 'label') as $f) {
			if (isset($changed[$f])) {
				$setparts[$f] = $new[$f];
			}
		}

		// Dates and amount are only propagated if the linked line is not reconciled
		if (empty($linked['rappro'])) {
			if (isset($changed['dateo'])) {
				$setparts['dateo'] = $new['dateo'];
			}
			if (isset($changed['datev'])) {
				$setparts['datev'] = $new['datev'];
			}

			if (isset($changed['amount']) || isset($changed['fk_account'])) {
				$linkedAmount = $this->computeLinkedAmount($new['fk_account'], $linked['fk_account'], $new['amount']);
				if ($linkedAmount !== null) {
					$setparts['amount'] = $linkedAmount;
				}
			}
		}

		$ctx = json_encode(array('source' => 'auto_sync', 'trigger_line_id' => (int) $lineid));

		if (!empty($setparts)) {
			$frags = array();
			foreach ($setparts as $col => $val) {
				if ($col === 'dateo' || $col === 'datev') {
					$frags[] = $col." = '".$this->db->escape($val)."'";
				} elseif ($col === 'amount') {
					$frags[] = "amount = ".((float) $val);
				} else {
					$frags[] = $col." = ".($val === '' ? "NULL" : "'".$this->db->escape($val)."'");
				}
			}
			$sql = "UPDATE ".MAIN_DB_PREFIX."bank SET ".implode(', ', $frags)." WHERE rowid = ".((int) $linkedId);
			$this->db->query($sql);

			foreach ($setparts as $col => $val) {
				BankAudit::logChange($this->db, $user, 'bank_line', $linkedId, 'UPDATE', $col, null, (string) $val, $ctx);
			}
		}

		if ($catsChanged) {
			BankAudit::syncLineCategories($this->db, $linkedId, $new['categs']);
			BankAudit::logChange($this->db, $user, 'bank_line', $linkedId, 'UPDATE', 'categories', null, implode(',', $new['categs']), $ctx);
		}

		BankAudit::$syncInProgress = false;
	}

	/**
	 * Compute the amount of the linked line from the source amount, applying the currency
	 * rule: opposite sign, multiplied by the conversion rate when currencies differ.
	 *
	 * @param int   $srcAccount Source account id
	 * @param int   $tgtAccount Target (linked) account id
	 * @param float $srcAmount  Source amount
	 * @return float|null        Linked amount, or null if the rate is unknown
	 */
	private function computeLinkedAmount($srcAccount, $tgtAccount, $srcAmount)
	{
		$srcCur = BankAudit::getAccountCurrency($this->db, $srcAccount);
		$tgtCur = BankAudit::getAccountCurrency($this->db, $tgtAccount);

		if ($srcCur === '' || $tgtCur === '') {
			return null;
		}
		if ($srcCur === $tgtCur) {
			return -1 * (float) $srcAmount;
		}

		$rate = BankAudit::getConversionRate($this->db, $srcCur, $tgtCur);
		if ($rate === null) {
			return null;
		}
		return round(-1 * (float) $srcAmount * $rate, 2);
	}

	/**
	 * Validate the source balance of each line of the internal transfer form.
	 *
	 * @param Translate $langs Language object
	 * @return bool             True if at least one line is blocked
	 */
	private function checkTransferBalances($langs)
	{
		global $conf;

		$blocked = false;
		for ($n = 1; $n < 20; $n++) {
			$accFrom = GETPOSTINT($n.'_account_from');
			$amount = (float) price2num(GETPOST($n.'_amount', 'alpha'), 'MT', 2);
			if ($accFrom <= 0 || $amount <= 0) {
				continue;
			}

			$threshold = BankAudit::getMinBalanceForAccount($this->db, $accFrom);
			if ($threshold === null) {
				continue; // no threshold configured for this account => no blocking
			}

			$balance = BankAudit::getAccountBalance($this->db, $accFrom);
			$after = $balance - abs($amount);
			if ($after < $threshold) {
				$blocked = true;
				$cur = BankAudit::getAccountCurrency($this->db, $accFrom);
				$msg = $langs->trans('BalanceGuardBlocked').' (#'.$n.') - ';
				$msg .= $langs->trans('AvailableBalance').': '.price($balance, 0, $langs, 1, -1, -1, $cur).' / ';
				$msg .= $langs->trans('BalanceAfterTransfer').': '.price($after, 0, $langs, 1, -1, -1, $cur);
				setEventMessages($msg, null, 'errors');
			}
		}

		return $blocked;
	}

	/**
	 * Render the change-tracking history table for a bank line.
	 *
	 * @param Translate $langs  Language object
	 * @param int       $lineid Bank line rowid
	 * @return string            HTML (a table row to insert in the line card table)
	 */
	private function renderLineHistory($langs, $lineid)
	{
		$langs->load('bankaudit@bankaudit');

		$sql = "SELECT l.tms, l.action, l.field_name, l.old_value, l.new_value, l.context,";
		$sql .= " u.rowid as uid, u.login, u.firstname, u.lastname";
		$sql .= " FROM ".MAIN_DB_PREFIX."bank_audit_log as l";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."user as u ON u.rowid = l.fk_user";
		$sql .= " WHERE l.object_type = 'bank_line' AND l.object_id = ".((int) $lineid);
		$sql .= " ORDER BY l.tms DESC, l.rowid DESC";

		$resql = $this->db->query($sql);

		$out = '<tr><td colspan="2">';
		$out .= '<div class="div-table-responsive-no-min" style="margin-top:6px">';
		$out .= '<table class="noborder centpercent">';
		$out .= '<tr class="liste_titre">';
		$out .= '<th>'.$langs->trans('AuditTrailTitle').'</th>';
		$out .= '<th>'.$langs->trans('AuditDateTime').'</th>';
		$out .= '<th>'.$langs->trans('AuditUser').'</th>';
		$out .= '<th>'.$langs->trans('AuditAction').'</th>';
		$out .= '<th>'.$langs->trans('AuditField').'</th>';
		$out .= '<th class="right">'.$langs->trans('AuditOldValue').'</th>';
		$out .= '<th class="right">'.$langs->trans('AuditNewValue').'</th>';
		$out .= '</tr>';

		$nb = 0;
		if ($resql) {
			while ($obj = $this->db->fetch_object($resql)) {
				$nb++;
				$username = '-';
				if (!empty($obj->uid)) {
					$username = trim($obj->firstname.' '.$obj->lastname);
					if ($username === '') {
						$username = $obj->login;
					}
				}
				$actionlabel = $langs->trans('AuditAction'.$obj->action);
				$autosync = '';
				if (!empty($obj->context) && strpos($obj->context, 'auto_sync') !== false) {
					$autosync = ' <span class="opacitymedium" title="'.dol_escape_htmltag($langs->trans('AuditContextAutoSync')).'">&#8635;</span>';
				}

				$out .= '<tr class="oddeven">';
				$out .= '<td></td>';
				$out .= '<td class="nowraponall">'.dol_print_date($this->db->jdate($obj->tms), 'dayhour').'</td>';
				$out .= '<td>'.dol_escape_htmltag($username).'</td>';
				$out .= '<td>'.dol_escape_htmltag($actionlabel).$autosync.'</td>';
				$out .= '<td>'.dol_escape_htmltag($obj->field_name).'</td>';
				$out .= '<td class="right">'.dol_escape_htmltag($obj->old_value).'</td>';
				$out .= '<td class="right">'.dol_escape_htmltag($obj->new_value).'</td>';
				$out .= '</tr>';
			}
		}

		if ($nb == 0) {
			$out .= '<tr class="oddeven"><td></td><td colspan="6" class="opacitymedium">'.$langs->trans('NoAuditRecordFound').'</td></tr>';
		}

		$out .= '</table></div>';
		$out .= '</td></tr>';

		return $out;
	}

	/**
	 * Build the JavaScript assistant injected at the bottom of the internal transfer page:
	 * automatic destination amount conversion (P3) and live source balance check (P2).
	 *
	 * @param Translate $langs Language object
	 * @return string           HTML <script> block
	 */
	private function getTransferAssistantJs($langs)
	{
		$langs->load('bankaudit@bankaudit');

		$out = "\n<!-- BankAudit transfer assistant -->\n";
		$out .= '<script type="text/javascript">'."\n";
		$out .= "(function(){\n";
		$out .= "var rateUrl=".json_encode(dol_buildpath('/bankaudit/ajax/get_conversion_rate.php', 1)).";\n";
		$out .= "var infoUrl=".json_encode(dol_buildpath('/bankaudit/ajax/get_account_info.php', 1)).";\n";
		$out .= "var token=".json_encode(newToken()).";\n";
		$out .= "var L_insufficient=".json_encode($langs->transnoentitiesnoconv('InsufficientBalance')).";\n";
		$out .= "var L_available=".json_encode($langs->transnoentitiesnoconv('AvailableBalance')).";\n";
		$out .= "var L_after=".json_encode($langs->transnoentitiesnoconv('BalanceAfterTransfer')).";\n";
		$out .= <<<'JS'
function selCur(sel){ if(!sel||sel.selectedIndex<0){return '';} var o=sel.options[sel.selectedIndex]; return o?(o.getAttribute('data-currency-code')||''):''; }
function num(v){ v=(''+v).replace(/\s/g,'').replace(',','.'); var f=parseFloat(v); return isNaN(f)?0:f; }
function fmt(n){ return (Math.round(n*100)/100).toFixed(2); }
var violations={};
var warnBox=document.createElement('div');
warnBox.id='bankaudit_transfer_warning';
warnBox.className='warning';
warnBox.style.display='none';
warnBox.style.margin='6px 0';
var form=document.querySelector('form[name="add"]');
if(form&&form.parentNode){ form.parentNode.insertBefore(warnBox, form); }
function renderWarn(){
	var msgs=[]; for(var k in violations){ if(violations[k]){ msgs.push(violations[k]); } }
	if(msgs.length){ warnBox.innerHTML=msgs.join('<br>'); warnBox.style.display='block'; }
	else { warnBox.innerHTML=''; warnBox.style.display='none'; }
}
var froms=document.querySelectorAll('select[name$="_account_from"]');
Array.prototype.forEach.call(froms, function(selFrom){
	var prefix=selFrom.name.replace('_account_from','');
	var selTo=document.querySelector('select[name="'+prefix+'_account_to"]');
	var inpAmount=document.querySelector('input[name="'+prefix+'_amount"]');
	var inpDest=document.querySelector('input[name="'+prefix+'_amountto"]');
	function updateConv(){
		if(!selTo||!inpAmount){ return; }
		var fromCur=selCur(selFrom), toCur=selCur(selTo), amt=num(inpAmount.value);
		if(!fromCur||!toCur||!amt){ return; }
		if(fromCur===toCur){ if(inpDest){ inpDest.value=fmt(amt); } return; }
		var url=rateUrl+'?token='+encodeURIComponent(token)+'&from='+encodeURIComponent(fromCur)+'&to='+encodeURIComponent(toCur);
		fetch(url,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
			if(d&&d.rate&&inpDest){ inpDest.value=fmt(amt*d.rate); }
		}).catch(function(){});
	}
	function checkBal(){
		var accId=selFrom.value;
		var amt=Math.abs(num(inpAmount?inpAmount.value:0));
		if(!accId||parseInt(accId,10)<=0){ violations[prefix]=''; renderWarn(); return; }
		var url=infoUrl+'?token='+encodeURIComponent(token)+'&id='+encodeURIComponent(accId);
		fetch(url,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
			if(!d||d.threshold===null||typeof d.threshold==='undefined'){ violations[prefix]=''; renderWarn(); return; }
			var after=d.balance-amt;
			if(after<d.threshold){
				violations[prefix]=L_insufficient+' (#'+prefix+') - '+L_available+': '+fmt(d.balance)+' '+(d.currency||'')+' / '+L_after+': '+fmt(after)+' '+(d.currency||'');
			} else { violations[prefix]=''; }
			renderWarn();
		}).catch(function(){});
	}
	function onChange(){ updateConv(); checkBal(); }
	['change','input'].forEach(function(ev){
		if(selFrom){ selFrom.addEventListener(ev,onChange); }
		if(selTo){ selTo.addEventListener(ev,updateConv); }
		if(inpAmount){ inpAmount.addEventListener(ev,onChange); }
	});
});
if(form){
	form.addEventListener('submit', function(e){
		for(var k in violations){ if(violations[k]){ e.preventDefault(); renderWarn(); if(warnBox.scrollIntoView){ warnBox.scrollIntoView(); } return false; } }
	});
}
JS;
		$out .= "\n})();\n</script>\n";

		return $out;
	}
}
